<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="./dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="./light.svg">
  <img alt="Monisha A — Aspiring Software Developer focused on Python, FastAPI, SQL, React and practical software projects." src="./dark.svg" width="100%">
</picture>

</div>

<h1 align="center">Hi, I'm Monisha 👋</h1>

<p align="center">
  Aspiring Software Developer · Python · FastAPI · SQL · React
</p>

<p align="center">
  I enjoy turning ideas into practical software through backend development, data workflows, and AI-assisted applications.
</p>

---

## About Me

- 🎓 B.E. Computer Science and Engineering — 2027 graduate
- 🧩 Interested in software development, backend APIs, data analytics, and AI-enabled tools
- 🛠️ Building projects that connect application development with useful data and system workflows
- 🌱 Continuously learning through hands-on projects and technical practice

## Featured Projects

### FutureMind AI — AI Regret Prediction Engine
A decision-support application designed to help users compare choices and explore potential regret, using Python, FastAPI, React, and Gemini AI.

### SentinelVault — Secure Cloud Storage & Security Platform
A security-focused project exploring secure file workflows, cryptographic concepts, access controls, and integrity auditing.

### E-Commerce Business Intelligence / ETL
A data workflow that extracts and cleans raw customer, order, and product data, then loads structured data into SQLite for analysis and business insights.

### Continuous Diabetic Foot Monitoring Using a Multi-Sensor Smart Insole
**Published patent application · Co-inventor**  
A sensor-based smart insole concept for monitoring plantar pressure, temperature, moisture, walking activity, gait characteristics, and fall events, with alerts to a connected device.  
Patent Application No. **202641109619 A** · Filed 12 Sep 2026 · Published 18 Sep 2026.

### Customer Intelligence Platform
**Ongoing academic project**  
Exploring customer churn analysis, segmentation, explainable model outputs, and earlier identification of customers who may be at risk.

## Technical Stack

- **Languages:** Python, C, C++, SQL, JavaScript
- **Backend & APIs:** FastAPI, Flask, REST APIs
- **Frontend:** HTML, CSS, JavaScript, React
- **Data & AI:** Pandas, NumPy, Matplotlib, machine learning fundamentals, Generative AI
- **Databases & Cloud:** SQLite, MySQL, Azure Blob Storage concepts
- **Tools:** Git, GitHub, VS Code

## Experience & Learning

- Python Development Intern — Cybernaut Tech Trio
- Cloud Computing Intern — Edufy
- Web Development Intern — CodeBind Technologies
- AI and Cloud internship experience — Pristine Code Technologies

## Connect

- **GitHub:** [MONISHA2006A](https://github.com/MONISHA2006A)
- **LinkedIn:** [Monisha A](https://linkedin.com/in/monisha-a-a23950303)
- **Portfolio:** [View Portfolio](https://gleaming-cascaron-c2eab2.netlify.app)
- **Email:** [monishaannaduari146@gmail.com](mailto:monishaannaduari146@gmail.com)

---

<p align="center">
  <i>Learn consistently. Build thoughtfully. Improve with every iteration.</i>
</p>
